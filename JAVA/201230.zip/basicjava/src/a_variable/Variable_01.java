package a_variable;
/**
 * 변수공부를 위한 첫번째 클래스
 * @author PC11
 * @since 2020.12.17
 */
public class Variable_01 {
	public static void main(String[] args) {//method
		//한줄주석
//		한
//		줄
//		주
//		석
		
		/*
		 * 변수란?
		 * 단 하나의 값을 저장할 수 있는 공간이다.
		 * 
		 */
	
		/*
		1. 변수의 선언 (이 이름을 선점하는 방식, 하나만 있어야 편하니까)
		     변수타입 변수명; family name 뒤에 것이 내 이름
		     이      영훈;
		   int  a;
		   int는 정수만 저장 가능 a라는 이름을 붙여놓은 것
		   
		2. 변수의 초기화
		   -변수명= 값;
		   -선언한 다음 쓸 수 있다
		   
		3.  변수의 선언 및 초기화
		-변수타입 변수명 = 값;		
		 */ 
		
		int name;
		
	
		
		
		
		name = 50;
		System.out.println(name);
		
		int name1 = 100;
		/*
		4. 명명규칙(4개)
		- 대소문자를 구분하며 길이의 제한이 없다.
	    - 예약어(key word, reserved word)는 사용할 수 없다.-이클립스에 쳤을때 보라색이면 예약어
	    - 숫자로 시작하면 안된다.
		- 특수문자는 '_' '$' 두 개만 사용 가능하다.		
    	
    	5. 필수는 아니지만 프로그래머로서의 암묵적인 약속들(가독성)
    	- 클래스의 명칭은 대문자로 시작해야한다.
    	- 여러단어로 이루어진 경우 첫번째 이후 단어의 첫 글자는 대문자로 써야 한다.
    	  lastIndexOf
    	- 상수의 이름은 모두 대문자로 쓴다. final int 최종값
    	  MAX_VALUE(이럴때 언더바 써먹어라)
		- 한글은 사용하지 않는다.
		*/
		// boolean name; ->
		
		
		
		int naMe;
		
		final int K = 50;
		
		
		
      }
}
