package z_exam;

public class Exam_05 {

	public static void main(String[] args) {
		
//		//5-1다음은 배열을 선언하거나 초기화한 것이다. 잘못된 것을 고르소 그애유를 설명4,5
//		int[] arr1 [];
//		int[] arr2 = {1,2,3};
//		int[] arr3 = new int[5];
////		int[] arr4= new int[5]{1,2,3,4,5};
////		int arr5[5];
//		int[] arr6 [] = new int[3][];
//		
//		//5-2다음과 같은 배열이 있을때 
//		//arr[3].length의 값은 얼마인가 2
//		//arr.length의 값은 얼마인가 3
//		//System.out.println(arr[4][1])의 출력 결과는 얼마인가 > 안나온다
//		int[][] arr = {{5,5,5,5,5},{10,10,10},{20,20,20,20},{30,30}};
//		
//		
//		//5-3배열arr에 담긴 모든 값을 더하는 프로그램을 완성하시오
//		int[] arr={10,20,30,40,50};
//		int sum = 0;
//		for(int i=0; i<arr.length; i++){
//			sum +=arr[i];//총합 : 150
//		}
//		
//		//5-4 2차원 배열 arr에 담긴 모근 값의 총합과 평균을 구하는 프로그램을 오나성하시오
//		int[][] arr = { {5,8,13,5,2}, {22,13,28}, {2,18,23,62}};
//		int total = 0;//합계를 저장하기 위한 변수
//		float average = 0;//평균을 저장하기위한 변수
//		
//		int count=0;
//		for(int i=0; i<arr.length; i++){
//			for(int j=0; j<arr[i].length; j++){
//				total += arr[i][j];
//				count++;
//			}
//		}
//		average = (int)(((float)total/count)*100+0.5)/100f;
//		System.out.println("total :"+total);
//		System.out.println("average :"+average);
		
		/* 5-5 거스름돈을 몇 개의 동전으로 지불할 수 있는지를 계산하는 문제이다.
		 * 변수 money의 금액을 동전으로 바꾸었을 때 각각 몇 개의 돈전이 필요한지 계산해서 출력하라
		 * 단 가능한 적은 수의 동전으로 거슬러 주어야한다.
		 * (1)에 알맞은 코드를 넣어서 프로그램을 완성
		 * 500:5개
		 * 100:2개
		 * 50 :1개
		 * 10 :4개
		 *  
		 */
		int[] soinUnit = {500, 100, 50, 10};
		int money = 2790;
		
		int coun =0;
		
		while(money !=0 ){
			if(money/soinUnit[0] < soinUnit[1] ){
				coun++;
			}else if(money/soinUnit[1] < soinUnit[2] ){
				
			}
			
		}
		/*
		 * 
		 * 
		 */
		
	}

}
