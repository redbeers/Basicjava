package z_exam;

public class Exam_04 {

	public static void main(String[] args) {
		
//		//4-1 다음의 문장들을 조건식으로 표현하라
//		int rendom = (int)(Math.random()*100+1);
//		//1.int형 변수 x가 10보다 크고 20보다 작을 때 true인 조건
//		int x =10;
//		if(x > 10 ? true : x < 20 ? true : false){
//		}
//		//2.char형 변수 ch가 공백이고 탭이 아닐 때 true인 조건식
//		char ch = 9;
//		System.out.println(ch);
//		if(ch == 0 ? false : ch == 9 ? false : true){
//			System.out.println(ch);
//		}
//		//3.char형 변수 ch가 x또는 (대)X일 때 true인 조건식
//		char ch3 = 'X';
//		if(ch3 == 'x'? true : ch3 == 'X' ?  true : false){
//			
//		}
//		
//		//4.char형 변수 ch가 숫자('0'~'9')일 때 true인 조건식 48~57
//		char ch4 = '0';
//		if(ch4 >= '0' && ch4 <= '9'){
//			System.out.println("t");
//		}else{
//			System.out.println("f");
//		}
//		boolean a = ch4 >= '0' && ch4 <= '9';
//		System.out.println(a);
//
//		//5.char형 변수 ch가 영문자(대문자 또는 소문지)일때 true인 조건식
//		char ch5 = 'A';
//		boolean a1 = ch5 >= 'A' && ch5 <= 'Z';
//		boolean a1_1 = ch5 >= 'a' && ch5 <= 'z';
//		if(a1 || a1_1){
//			System.out.println("t");
//		}else{
//			System.out.println("f");
//		}
//		//6.boolean형 변수 powerOn가 false일 때 true인 조건
//		boolean powerOn = false;
//		if(powerOn == false){
//			System.out.println("true");
//		}
//
//		//7.문자열 참조변수 str이 yes일 때 true인 조건식
//		String str = "yes";
//		if(str == "yes"){
//			System.out.println("true");
//		}
//		//4-2 1부터 20까지의 정수 중에서 2 또는 3의 배수가 아닌 수의 총합을 구하시오
//		// (1:20:1:sum +=?)
//		int sum4=0;
//		
//		for(int a=1; a<21; a++){
//			if(a%2 != 0 && a%3 != 0){
////			if(a%2 == 1 || a%3 == 1){	
//				sum4 += a;
//			}
//		}
//		System.out.println(sum4);
		//홀수와 2의배수랑 뭐가 다른가?
		//홀수 :  	  1,3,5,7,9..
		//짝수(2의배수) : 2,4,6,8,10..
		//4-3다음의 for문을 while문으로 변경하시오
//		for(int dan = 2; dan < 10; dan++){
//			for(int gob = 1; gob < 10; gob++){
//				System.out.println(dan + " * " + gob + " = " + dan * gob);
//			}
//		}
//		// 2:9:1: dan *= ?;
//		// 1:9:1: gob *= ?;
//		int dan = 2;
//		
//		while(dan<10){
//			int gob = 1;
//			while(gob<10){
//			System.out.println(dan + "*"+gob+"="+dan*gob);
//			gob++;
//			}
//			dan++;
//		}
//		
//		//4-4 두 개의 주사위를 던졌을 때 눈의 합이 6이 되는 모든 경우의 수를 풀력하는 프로그램 작성
//		// 1:6:1:sum
//		int sum = 0;
//		for(int d1 = 1; d1<7; d1++){
//			for(int d2 = 1; d2<7; d2++){
//				if(d1+d2 ==6)
//					System.out.println(d1+","+d2);
//			}
//		}
//		
//		//4-5 방정식 2x + 4y = 10의 모든 해를 구하시고 단 x와 y는 정수이고 각각의 범위는 0<=x,y<=10
//		//1:10:1: sum +=a+b
//		//1:10:1: sum +=a+b
//		int x =2;
//		int y =4;
//		int sum =0;
//		for(int a=1; a<11; a++){
//			for(int b=1; b<11; b++){
//				if((2*a) + (4*b) == 10){
//					System.out.println(a + ","+b);
//				}
//				
//			 }
//		}
		
		//4-6 사용자로부터 두개의 정수(시작,끝)를 입력받아 시작(포함)에서 끝(포함)까지의 곱을 출력하는 그로그램을 작성
		
		//4-8  1 + (1+2) + (1+2+3).....(1+2+3+....10), 2 + (1+2) + (1+2+3).....(1+2+3+....10),......10 + (1+2) + (1+2+3).....(1+2+3+....10) 
		
		//4-9 사용자로부터 입력받은 정수의 각 자리의 합을 더한 겨과를 출력하는 프로그램을 작성하시오
		//예 사용자가 53263을 입력하였다면 결과는 19가 되어야 한다.
		
		//4-10 피보나치(Fibonnaci) 수열은 앞을 두 수를 더해서 다음 수를 만들어 나가는 수열이다.
		//예 앞의 두 수가 1과 1이라면 그 다음 수는 2가 됙 그 다음 수는 1과 2를 더해서 3이 되어서 1,1,2,3,5,8,13,21......과 같은 식으로 ㅅ진행
		//1과 1부터 시작하는 피보나치수열의 10번째 수는 무엇인지  셰산하는 프로그램 작성
		
		
		
	}

}
