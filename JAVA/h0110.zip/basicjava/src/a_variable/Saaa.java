package a_variable;

public class Saaa {

	public static void main(String[] args) {
		int[] arr={4,1,2,3};
		int a = arr[0];	
		for(int i=0; i<arr.length; i++){
			if(a > arr[i]){
				a=arr[i];
                arr[i]=arr[i+1];
                arr[i+1] = a;
            }
			System.out.println(arr[i]);
		}
    }
}
