package f_oop2;

import e_oop.ProtectedTest_03;

public class ProtectedTest_01 extends ProtectedTest_03{
	public static void main(String[] args) {
		ProtectedTest_02 pt2 = new ProtectedTest_02();
		ProtectedTest_03 pt3 = new ProtectedTest_03();
		ProtectedTest_01 pt1 = new ProtectedTest_01();
		
		//pt1.b//protected 변수
		
		
	}

}
