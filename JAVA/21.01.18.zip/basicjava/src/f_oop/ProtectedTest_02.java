package f_oop;

public class ProtectedTest_02 {
	public int a;
	protected int b;
	int c;
	private int d;
	
	public ProtectedTest_02() {
		
	}
}

