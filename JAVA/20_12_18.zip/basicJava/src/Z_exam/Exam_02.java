package Z_exam;

public class Exam_02 {
	public static void main(String[] args){
		
		/*
		 * 2-1다음 표의 빈 킨에 8개의 기본형 (primitive type)을 알맞은 자리에 넣으시오
		 * 			1byte		2byte		4byte		8byte
		 * 
		 * 	논리형	boolean
		 * 	문자형				char
		 * 	정수형	byte		short		int			long
		 * 	실수형							float		double
		 * 	
		 * boolean > 논리형 > 1byte >8bit
		 * char > 문자형 > 2byte > 16bit
		 * byte > 정수형 > 1byte > 8bit
		 * short > 정수형 > 2byte > 16bit
		 * int > 정수형 > 4byte > 32bit
		 * long > 정수형 > 8byte > 64bit
		 * float > 실수형 > 4byte > 32bit
		 * double > 실수형 > 8byte > 64bit
		 * 
		 */
		
		/*
		 * 2-2다음의 문장에서 리터럴, 변수, 상수, 키워드를 적으시오
		 * 	int i = 100;
		 * 	long l = 100L;
		 * 	final float PI = 3.14f;
		 * 
		 * 	- 리터럴 : 100, 100L, 3.14f  
		 * 		(프로그래밍에서는 상수를 다른 이름으로 불러야해서 상수대신 리터럴이라 칭한다.
		 *  - 변수 : i, l, Pl
		 *  	(값을 저장하는 메모리상의 공간
		 *  - 키워드 : int , long, final, float
		 *  	(예약어이며 Eclipse에서 보라색으로 표시된다.
		 *  - 상수 : Pl
		 *  	(변수와 같은 값을 저장 공간이지만 한번저장되면 값을 변경할수없다.변수 타입 앞에 final로 표시한다.
		 * 		예)final int a = 10;
		 */
		
		/*
		 * 2-3다음 중 기본형(primitive type)이 아닌 것은 2
		 * 1.int > 정수형
		 * 2.Byte > 첫글자가 대문자면 클래스를 의미한다.
		 * 3.double > 실수형
		 * 4.boolean > 논리형
		 */
		
		/*
		 * 2-4다음 문장들의 출력결화를 적으세요. 오류가 있는 문장의 경우, 괄호 안에 '오류'라고 적으시오
		 * System.out.println("1" + "2"); >String+String > String + String
		 * System.out.println(true + ""); > doolean + String > String + String
		 * System.out.println('A' + 'B'); > char + char >char+char
		 * System.out.println('1' + 2); > char + int > int+int
		 * System.out.println('1' + '2'); > char + char > char + char
		 * System.out.println(4 + 24.3719F); > int + float > float + float
		 * System.out.println('A' + 3.14); > char + double  > double + double 
		 * 		(정수로 변환되어 처리하기 때문에 A의 아스키코드 숫자 + 3.14 를 실행한다.   
		 * System.out.println('J' + "ava"); > char + String > String + String
		 * System.out.println(true + null 오류); >boolean + String 
		 * 		(true는 기본형으로 값을 저장하지만 null은 참조형 이기때문에 주소를 저장하기때문에 자바는 연산하지못한다.
		 * 		실제 연산에 사용되는 것은 기본형 변수이다.   
		 * 
		 */
		
		/*
		 * 2-5다음 중 키워드가 아닌 것은? 2~5
		 * 1.if > 예약(key word이다
		 * 2.True
		 * 3.NULL
		 * 4.Class
		 * 5.System
		 */
		
		/*
		 * 2-6다음 중 변수의 이름으로 사용할 수 있는 것은 1,4,7
		 * 1.$sytem 
		 * 2.cannel#5 > 특수문자는 $, _ 만 사용가능하다
		 * 3.7eleven > 변수이름은 숫자로 시작할 수 없다
		 * 4.lf > if라면 예약어(key word, reserved word
		 * 5.자바 >변수 이름을 한글은 사용하지 않는다
		 * 6.new >예약어(key word, reserved word
		 * 7.$MAX_NUM > 상수라서 final을 사용해야 사용가능
		 * 8.hello@com >특수문자는 $, _ 사용 가능하다
		 * 
		 */
		
		/*
		 * 2-7참조형 변수(reference type)와 같은 크기의 기본형(primitive type)은 1,4
		 * 		(참조형은 4byte 이다
		 * 1.int > 4byte
		 * 2.long > 8byte
		 * 3.short > 2byte
		 * 4.float > 4byte
		 * 5.double > 8byte
		 */
		
		/*
		 * 2-8다음 중 형변환을 생략할 수 있는 것은 1,5
		 * byte b = 10;
		 * char ch = 'A';
		 * int i = 100;
		 * long l = 1000L;
		 * 
		 * byte > short > char > int > loag
		 * - 포함가능한 범위
		 * 
		 * 1.b = (byte)i; > byte int
		 * 2.ch = (char)b; > char 
		 * 3.shor s = (short)ch; > 
		 * 4.float f = (float)l; > 
		 * 5.i = (int)ch; > 
		 */
		
		/*
		 * 2-9char타입의 변수에 저장될 수 있는 정수 값의 범위는
		 * 0~2에16승 -1
		 * char는 부호가 없기때문에-를 표현하지 않는다.
		 */
		
		/*
		 * 2-10다읍중 변수를 잘못 초기화 한 것은 1~4
		 * 1.byte b = 256; > byte는 -128 ~ 127까지만 들어간다.
		 * 2.char c = ''; > char는 빈값을 넣을 수 없다.
		 * 3.char answer = 'no'; > char는 한 개의 값만 들어간다.
		 * 4.float f = 3.14 > float은 f를 써야한다, ;가 생략되었다.
		 * 5.double d = 1.4e3f; > f는 float을 뜻 하는 것이다.
		 */
		
	}
}
