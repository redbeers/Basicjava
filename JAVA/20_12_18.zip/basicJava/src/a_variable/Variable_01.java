package a_variable;
/**
 * 번수공부를 위한 첫번째 클래스
 * @author PC10 저자
 * @since 2020.12.17
 */
public class Variable_01 {
	public static void main(String[] args){//method
		/* mai에 이있어야 실행된다.
		 
		 * 독주석  //**
		 * f2 설명확인
		 * 주석처리 단축키 ctrl+shift+c
		 *
		 * 변수란
		 * 단 하나의 값을 저장할 수 있는 공간이다.
		 *	변수 이름을 선언하면 다른 곳 에서 사용 못한다.
		 *
		 * 1. 변수의 선언
		 * -변수타입 변수명;
		 * 	박	상빈;
		 * 	int 	a;(정수만 가질수 있다.
		 * 	변수타입 변수명
		 * 
		 * 2. 변수의 초기화(변수에 값을 넣어준다.
		 * -변수명= 값;
		 * 
		 * 3.변수의 선언 및 초기화
		 * -변수타입 변수명 = 값;
		 * 
		 
		 */
		int a;
		int name;
		name = 20;
		System.out.println(name);
		name = 50;
		System.out.println(name);
		int name1 = 100;
//		boolean name; =>변수명이 선언되어있다.
		
		/*
		 * 4. 명명규칙(변수명,메서드명(동사적인것),클래스명
		 * -대소문자구분, 길이의 제한없음
		 * -예약어(key word, reserved word)는 사용 불가(이름이 보라색이면 예약어
		 * -숫자로 시작이 불가능
		 * -특수문자는 _ , $만 사용가능
		 * 
		 * 5.필수는 아니지만 프로그래머로서의 암목적이 약속들 (가독성)
		 * -클래스의 명은 대문자로 시작한다, 메서드뒤에는 소가로()가있다.
		 * -여러단어로 이루어진 경우 첫번째 이후 단어의 첫 글자를 대문자로 써야한다.
		 * 예)lastIndexOf
		 * -상수의 이름은 모두 대문자로 쓴다.
		 * MAX_VALUE
		 * -한글은 사용하지 않는다.
		 *
		 */
		
		
		int naMe;
		final int k=50;
		//k=90;
		
		
		

		
		
	}

}
